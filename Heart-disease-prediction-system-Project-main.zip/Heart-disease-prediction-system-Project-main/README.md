# Title :

# Heart-disease-prediction-system-Project

Or 

# Heart disease prediction system using Machine Learning


Heart disease prediction system Project with Code and Report
 
### Abstract:

Cardiovascular disease (CVD) is a big reason of morbidity and mortality in the current living style. Identification of Cardiovascular disease is an important but a complex task that needs to be performed very minutely, efficiently and the correct automation would be very desirable. Every human being can not be equally skillful and so as doctors. All doctors cannot be equally skilled in every sub specialty and at many places we don't have skilled and specialist doctors available easily. An automated system in medical diagnosis would enhance medical care and it can also reduce costs. In this study, we have designed a system that can efficiently discover the rules to predict the risk level of patients based on the given parameter about their health. The rules can be prioritized based on the user's requirement. The performance of the system is evaluated in terms of classification accuracy and the results shows that the system has great potential in predicting the heart disease risk level more accurately.


### Youtube Video Explanation of this Project : https://youtu.be/b0z32XjpMJ4

### Base Research Paper : https://ieeexplore.ieee.org/document/7148346

### Need Code, Documents & Explanation video ? 

## How to Reach me :

### Mail : vatshayan007@gmail.com 

### WhatsApp: **+91 9310631437** (Helping 24*7) **[CHAT](https://wa.me/message/CHWN2AHCPMAZK1)** 

### Website : https://www.finalproject.in/

### 1000 Computer Science Projects : https://www.computer-science-project.in/

Mail/Message me for Projects Help 🙏🏻

### Youtube Video Explanation of this Project : https://youtu.be/b0z32XjpMJ4

Another Disease Prediction System Project : https://github.com/Vatshayan/Final-Year-Disease-Prediction-Project

IMP : If you are getting error/problems/queires then Reach me will help you
